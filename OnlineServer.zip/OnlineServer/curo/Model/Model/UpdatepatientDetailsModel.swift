//
//  UpdatepatientDetailsModel.swift
//  curo
//
//  Created by SAIL on 19/03/24.
//

import Foundation
struct UpdatepatientDetailsModel: Codable {
    let status, message: String
}
