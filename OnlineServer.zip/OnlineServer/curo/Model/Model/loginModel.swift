//
//  loginModel.swift
//  curo
//
//  Created by SAIL on 25/03/24.
//

import Foundation

struct loginModel: Codable {
    let status, message: String
}
