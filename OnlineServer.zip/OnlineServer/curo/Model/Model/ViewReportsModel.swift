//
//  ViewReportsModel.swift
//  curo
//
//  Created by SAIL on 19/03/24.
//

import Foundation
struct ViewReportsModel: Codable {
    let status: String
    let images: [String]
}

