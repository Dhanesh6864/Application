//
//  uploadeReportsModel.swift
//  curo
//
//  Created by SAIL on 21/03/24.
//

import Foundation
struct uploadeReportsModel: Codable {
    let status, message: String
}

typealias uploadeReportsdata = [uploadeReportsModel]
