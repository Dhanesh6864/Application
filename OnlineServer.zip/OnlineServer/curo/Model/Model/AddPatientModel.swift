//
//  AddPatientModel.swift
//  curo
//
//  Created by SAIL on 26/03/24.
//
//
//import Foundation
//
//struct AddPatientModel: Codable {
//    let status, message, patient_id: String
//
//    enum CodingKeys: String, CodingKey {
//        case status, message
//        case patientID = "patient_id"
//    }
//}

