//
//  ReportsTableViewCell.swift
//  curo
//
//  Created by SAIL on 19/03/24.
//

import UIKit

class ReportsTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var reportImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
