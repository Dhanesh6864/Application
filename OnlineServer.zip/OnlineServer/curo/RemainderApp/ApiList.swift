
import Foundation
import UIKit


struct ApiList {
    static let baseUrl = "http://192.168.238.24/php/" ///
    ///
    ///
    ///
    static let loginURL = baseUrl+"dlogin.php?"
    static let ploginURL = baseUrl+"plogin.php?"
    static let PatientListURL = baseUrl+"plist.php"
    static let PatientDetailsURL = baseUrl+"patient_details_doctor.php"
  
    
    
  
}
